title: xorm 文档笔记-02
date: '2019-09-20 09:05:37'
updated: '2019-09-20 18:18:22'
tags: [Go, SQL, 数据库]
permalink: /articles/2019/09/20/1568941537549.html
---
# 插入数据

插入数据使用Insert方法，Insert方法的参数可以是一个或多个Struct的指针，一个或多个Struct的Slice的指针。

如果传入的是Slice并且当数据库支持批量插入时，Insert会使用批量插入的方式进行插入。

* 插入一条数据，此时可以用Insert或者InsertOne

```Go
user := new(User)
user.Name = "myname"
affected, err := engine.Insert(user)
// INSERT INTO user (name) values (?)

```

在插入单条数据成功后，如果该结构体有自增字段(设置为autoincr)，则自增字段会被自动赋值为数据库中的id。这里需要注意的是，如果插入的结构体中，自增字段已经赋值，则该字段会被作为非自增字段插入。

* 插入砼一个表的多条数据，此时如果数据库支持批量插入，那么会进行批量插入，但是这样每条记录就无法被自动赋予id值。如果数据库不支持批量插入，那么就会一条一条插入。

```
users := make([]User, 1)
users[0].Name = "name0"
...
affected, err :=engine.Insert(&users)
```

* 使用指针Slice插入多条记录，同上
```
users := make([]*User, 1)
users[0] = new(User)
users[0].Name = "name0"
...
affected, err := engine.Insert(&users)
```

* 插入多条记录并且不使用批量插入，此时实际生成多条插入语句，每条记录均会自动赋予id值。
```
users := make([]*User, 1)
user[0] = new(User)
users[0].Name = "name0"
...
affected, err := engine.Insert(users...)
```

* 插入不同表的一条记录
```
user := new(User)
user.Name = "myname"
question := new(Question)
question.Content = "whywhywhwy?"
affected, err := engine.Insert(user, question)
```

* 插入不同表的多条记录
```
users := make([]User, 1)
users[0].Name = "name0"
...
questions := make([]Question, 1)
questions[0].Content = "whywhywhyy?"
...
affected, err := engine.Insert(&users, &questions)
```

* 插入不同表的一条活多条记录
```
user := new(User)
user.Name = "myname"
...
questions := make([]Question, 1)
questions[0].Content = "whywhywhyy?"
affected, err := engine.Insert(user, &questions)
```
需要注意以下几点：
>> 1、这里虽然支持同时插入，但这些插入并没有事务关系。因此有可能在中间插入出错后，后面的插入将不会继续。此时前面的插入已经成功，如果需要回滚，请开启事务。
>> 2、批量插入会自动生成`Insert into table values (), (), ()`因此各个数据库对SQL语句有长度限制，因此这样的语句有一个最大的记录数，根据经验测算在150左右。大于150条后，生成的SQL语句将太长可能导致执行失败。在此在插入大量数据时，目前需要自行分割成每150条插入一次。

* 创建时间Created：Created可以让您在数据插入到数据库时自动将对应的字段设置为当前时间，需要在xorm标记中使用created标记，如下所示进行标记，对应的字段可以为time.Time或者自定义的time.Time或者int,int64等int类型。
```
type User struct {
	Id		int64
	Name 		string
	CreatedAt	time.Time `xorm:"created"`
}
```
或
```
type JsonTime time.Time
func (j JsonTime) MarshalJSON() ([]byte, error) {
	return []byte(`"`+time.Time(j).Format("2006-01-02 15:04:05")+ `"`), nil
}

type User struct {
	Id 		int64
	Name 		string
	CreateAt	JsonTime `xorm:"created"`
}
```
或
```
type User struct {
	Id		int64
	Name		string
	CreatedAt	int64 `xorm:"created"`
```

在Insert()或InsertOne()方法被调用时，created标记的字段将会被自动更新为当前时间或者当前时间的秒数(对应为time.Unix()),如下所示：
```
var user User
engine.Insert(&user)
// INSERT user (created...) VALUES (?...)
```
最后一个值得注意的是时区问题，默认xorm采用Local时区，所以默认调用time.Now()会先被转换成对应的时区。要改变xorm时区，可以使用：
```
engine.TZLocation, _ = time.Location("Asia/Shanghai")
```

# 查询和统计数据

所有的查询条件不区分调用顺序，但必须在调用Get,Exist,Sum,Find,Count,Iterate,Rows这几个函数之前调用。同时需要注意的一点是，在调用的参数中，如果采用默认的SnakeMapper所有的字符字段名均为映射后的数据库的字段名，而不是field的名字。

* **Get方法**

查询单条数据使用Get方法，在调用Get方法时需要传入一个对应结构体的指针，同时结构体中的非空field自动成为查询的条件和前面的方法条件组合在一起查询。

1. 根据Id来获得单条数据：
```
user := new(User)
has, err := engine.Id(id).Get(user)
//复合主键的获取方式
//has, errr := engine.Id(xorm.PK{1,2}).Get(user)
```

2. 根据Where来获得单条数据：
```
user := new(User)
has, err := engine.Where("name=?", "xlw").Get(user)
```

3. 根据user结构体中已有的非空数据来获得单条数据：
```
user := &User{Id:1}
has, err := engine.Get(user)
```
或者其他条件
```
user := &User{Name:"xlw"}
has, err := engine.Get(user)
```
返回的结果为两个参数，一个has为该条记录是否存在，第二个参数err为是否有错误。不管err是否为nil,has都有可能为true或false。

* **Exist系列方法**

判断某个记录是否存在可以使用`Exist`，相比GEt，Exist性能更好。
```
has, err := testEngine.Exist(new(RecordExist))
// SELECT * FROM record_exist LIMIT 1
```
```
has, err := testEngine.Exist(&RecordExist{
			Name: "test1",
	})
//SELECT * FROM record_exist WHERE name = ? LIMIT 1
```
```
has, err = testEngine.Where("name = ?", "test1").Exist(&RecordExist{})
//SELECT * FROM record_exist WHERE name = ? LIMIT 1
```

```
has, err = testEngine.SQL("select * from record_exist where name = ?", "test1").Exist()
//select * From record_exist where name = ?
```

```
has, err = testEngine.Table("record_exist").Exist()
// SELECT * FROM record_exist LIMIT 1
```

```
has, err = testEngine.Table("record_exist").Where("name = ?", "test1").Exist()
// SELECT * FROM record_exist WHERE name = ? LIMIT 1
```

Get与Exist方法返回值都为bool和error，如果查询到实体存在，则Get方法会将查到的实体赋值给参数。

如果你的需求是：判断某条记录是否存在，若存在，则返回这条记录。
建议直接使用Get方法。
如果仅仅判断某条记录是否存在，则使用Exist方法，Exist的执行效率要比Get更高。
```
user := &User{Id:1}
has, err := testEngine.Get(user) //执行结束后，user会被赋值为数据库中ID为1的实体

has, err := testEngine.Exist(user) //user中仍然是初始声明user,不做改变
```

* **Find方法**

查询多条数据使用Find方法，Find方法的第一个参数为slice的指针或map指针，即为查询后返回的结果，第二个参数可选，为查询的条件Struct的指针。

1.传入Slice用于返回数据
```
everyone := make([]Userinfo, 0)
err := engine.Find(&everyone)

pEveryOne := make([]*Userinfo,0)
err := engine.Find(&pEveryOne)
```

2.传入map用户返回数据，map必须为map[int64]Userinfo的形式，map的key为id，因此对于复合主键无法使用这种方式。
```
users := make(map[int64]Userinfo)
err := engine.Find(&users)

pUsers := make(map[int64]*Userinfo)
err := engine.Find(&pUsers)
```

3.也可以加入各种条件
```
users := make([]Userinfo, 0)
err := engine.Where("age > ? or name = ?", 30, "xlw").Limit(20,10).Find(&users)
···

4.如果只选择单个字段，也可使用非结构体的Slice
```
var ints []int64
err := engine.Table("user").Cols("id").Find(&ints)
```

* **Join的使用**

`Join(string,interface{},string)`
