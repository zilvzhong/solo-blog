title: 使用Devise + CanCanCan + rolify控制权限指南
date: '2019-08-29 12:11:06'
updated: '2019-08-29 12:11:06'
tags: [Rails]
permalink: /articles/2019/08/29/1567051866303.html
---
## devise、cancan和rolify这三个组件结合，可以建立完整而强大的用户权限模型。

[devise](https://github.com/plataformatec/devise)介绍：负责用户注册、登录、退出、找回密码等操作。

[cancan](https://github.com/CanCanCommunity/cancancan)介绍： 负责角色建立、对角色授权、在页面中根据授权是否显示元素，以及模型中超出授权时抛出异常。 

[rolify](https://github.com/RolifyCommunity/rolify)介绍：负责将用户与角色关联。

下面就简单介绍下这三者结合使用的方法，比较浅，深层次的大家自己去看文档挖掘，这里仅仅介绍最基本的使用。

# 安装

~编辑Gemfile加入Devise、CanCanCan、rolifyGems,运行```bundle install```:

```
gem 'devise'
gem 'cancancan'
gem 'rolify'

```

-运行以下命令来生成和权限管理的功能的用户模型。

```
$ rails generate devise:install   #运行Devise生成器
$ rails generate devise User      #从Devise创建用户模型
$ rails generate cancan:ability   #CanCanCan创建Ability类
$ rails generate rolify Role User #从rolify创建Role类
$rake db:migrate                  #运行迁移

```

## Devise的设定

* 在此不写了，大家可以去看我的这篇文章[认证系统之Devise使用指南](http://ippw.pw/2016/12/01/devise1/).

## CanCanCan权限的设定

* 在```models/ability.rb```给所有用户权限定义。

```
class Ability
  include CanCan::Ability

  def initialize(user)
    user ||= User.new # guest user (not logged in)
    if user.has_role? :admin
      can :manage, :all
    else
      can :read, :all
    end
  end
end

```

-- user.has_role?您可以使用任何符号的参数

-- can的第一个参数，:manage，:create，:read，:update，:destroy指定权限.

-- can第二个参数，指定目标对象的类名

全面介绍"[CanCanCan Defining Abilities](https://github.com/CanCanCommunity/cancancan/wiki/Defining-Abilities）位于。

* 授权控制器

```

class ArticlesController < ApplicationController
  load_and_authorize_resource

  def show
    # @article is already loaded and authorized
  end
end

```

## rolify向用户分配角色

* ```ralis console```创建用户，分配管理员角色

```

> user = User.new
> user.email = "email.com"
> user.password = "123.com"
> user.save
> user.add_role "admin"

```

用户可以分配多个角色

* 要切换用户的角色显示

home.html.erb

```

<% if current_user.has_role? :admin %>
   仅显示给管理员用户查看的内容。。。
<% end %>

```