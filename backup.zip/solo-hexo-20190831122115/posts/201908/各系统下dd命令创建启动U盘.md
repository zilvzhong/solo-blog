title: 各系统下dd命令创建启动U盘
date: '2019-08-29 12:11:02'
updated: '2019-08-29 12:11:02'
tags: [Mac]
permalink: /articles/2019/08/29/1567051862825.html
---
## dd命令详解：

> dd if=/dev/disk3 of=data.bak bs=512 count=1

命令参数：

- if=file：指定输入文件名，缺省为标准输入
- of=file：指定输出文件名，缺省为标准输出
- ibs=bytes：一次读入 bytes 个字节，即指定一个块大小为 bytes 个字节
- obs=bytes：一次输出 bytes 个字节，即指定一个块大小为 bytes 个字节
- bs=bytes：同时设置读入/输出的块大小为 bytes 个字节
- cbs=bytes：一次转换 bytes 个字节，即指定转换缓冲区大小
- skip=blocks：从输入文件开头跳过 blocks 个块后再开始复制
- seek=blocks：从输出文件开头跳过 blocks 个块后再开始复制
- count=blocks：仅复制 blocks 个块，块大小等于 ibs 指定的字节数

>> dd命令应用场景：

备份MBR

``` 
dd if=/dev/sda of=/mnt/data/MBR bs=1 count=512
```

备份数据

``` 
dd if=/dev/sda of=/data/sda.bak 备份sda的数据到/data
dd if=/dev/sda | gzip >/data/sda.gz 备份/dev/sda全盘数据，并利用gzip 压缩
```

恢复数据
``` 
dd if=/data/sda.bak of=/dev/sdb   将sda备份文件sda.bak恢复到/dev/sdb磁盘  
gzip -dc /data/sda.gz | dd of=/dev/sdb   将压缩的sda.gz文件恢复到/dev/sdb设备 
```
测试磁盘读写
```
time dd if=/dev/zero of=/testw.dbf bs=4k count=100000  测试磁盘写能力
time dd if=/dev/sdb of=/dev/null bs=4k 测试磁盘读能力
time dd if=/dev/sdb of=/testrw.dbf bs=4k 同时测试读写能力
```


## MAC下系统启动U盘制作：

 dd 针对的是扇区级别，对 blocks 进行操作。所以可以用它来做整盘数据的备份与恢复、备份 MBR 及启动盘的制作等。
 
 **1、镜像格式转换**
 
 > macOS系统是不支持直接读取iso镜像文件的，需要使用hdiutil命令进行格式转换，才可以使用dd命令读取。
 
hdiutil convert -format UDRW -o <dmg 文件> <iso 文件>
 * -format 指定生成文件的权限
 * UDRW 表示转换成有 read/write 权限的镜像
 
 ```
 hdiutil convert -format UDRW -o debian-9.5.0.dmg debian-9.5.0-amd64-netinst.iso
 ```
![](/images/posts/mac/dmg.png)

**2、卸载U盘**

```
diskutil list  查看U盘的设备号
diskutil unmountDisk /dev/disk3 使用diskutil的unmountDisk 选项来卸载U盘

```
![](/images/posts/mac/diskutil.png)

**3、写入U盘**

```
dd if=debian-9.5.0.dmg of=/dev/disk3 bs=1m
```

## Linux下系统启动U盘制作

**1、挂载镜像文件**
```
mkdir -p /tmp/cdrom
mount -o loop,exec debian-9.5.0-amd64-netinst.iso /tmp/cdrom
```

**2、查看U盘设备**
```
fdisk -l 
```
**3、写入U盘**
```
dd if=/tmp/cdrom of=/dev/sdb
umount /tmp/cdrom
```

**最后享个工具：** [SYSTEMRESCUECD](http://www.system-rescue-cd.org/)是一个Linux 系统救援磁盘，可用作可启动的CD-ROM或USB记忆棒，用于在崩溃后管理或修复您的系统和数据。它旨在提供一种在计算机上执行管理任务的简便方法，例如创建和编辑硬盘分区。它附带了许多 Linux系统实用程序，如GParted，fsarchiver，文件系统工具和基本工具（编辑器，午夜指挥官，网络工具）。它既可用于Linux和Windows 计算机，也可用于 台式机和服务器。此救援系统无需安装，因为它可以从CD / DVD驱动器或 USB记忆棒启动，但它可以 安装在硬盘上 如果你希望。内核支持所有重要的文件系统（ext3 / ext4，xfs，btrfs，reiserfs，jfs，vfat，ntfs），以及网络文件系统，如Samba和NFS。