title: Mysql 查看某时间段SQL
date: '2019-09-18 20:20:01'
updated: '2019-09-18 20:20:43'
tags: [数据库, SQL]
permalink: /articles/2019/09/18/1568809201459.html
---
* 1、查看当天日期
`select current_date();`

* 2、查看当天时间
`select current_time();`

* 3、查看当天时间日期
`select current_timestamp();`

* 4、查询当天记录
`select * from 表名 where to_days(时间字段名)=to_days(now());`

* 5、查询昨天记录
`select * from 表名 where to_days(now())-to_days(时间字段名)<=1

* 6、查询七天的记录
`select _ from 表名 where date_sub(curdate(), interval 7 DAY) <= date(时间字段名)`

* 7、查询近30天的记录
`select * from 表名 where date_sub(curdate(), interval 30 DAY) <= date(时间字段名)`

* 8、查询本月的记录
`select * from 表名 where date_format(时间字段名, '%Y%m') = date_format(curdate(), '%Y%m')`

* 9、查询上一月的记录
`select * from 表名 where period_diff(date_format(now(), '%Y%m'), date_format(时间字段名, '%Y%m')) = 1`

* 10、查询本季度数据
`select * from 表名 where QUARTER(create_date)=QUARTER(now());`

* 11、查询上季度数据
`select * from 表名 where QUARTER(create_date)=QUARTER(DATE_SUB(now(),interval 1 QUARTER));`

* 12、 查询本年数据
`select * from 表名 where year(create_date)=YEAR(now());`

* 13、 查询上年数据
`select * from 表名 where year(create_date)=year(date_sub(now(),interval 1 year));`

* 14、 查询当前这周的数据
`select * from 表名 where YEARWEEK(date_format(submittime, '%Y-%m-%d'))=YEARWEEK(now());`

* 15、 查询上周的数据
`select * from 表名 where WEARWEEK(date_format(submittime, '%Y-%m-%d'))=YEARWEEK(now())-1;`

* 16、 查询当前月份的数据
`select * from 表名 where date_format(submittime, '%Y-%m')=date_format(now(),'%Y-%m');`

* 17、查询距离当前现在6个月的数据
`select * from 表名 where submittime between date_sub(now(),interval 6 month) and now();`

* 18、查询一年前的数据
`select * from 表名 where str_to_date(entry_date, '%Y-%m-%d') < DATE__SUB(now(), INTERVAL 1 YEAR);`
