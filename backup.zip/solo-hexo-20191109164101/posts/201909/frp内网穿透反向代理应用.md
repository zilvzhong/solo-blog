title: frp-内网穿透反向代理应用
date: '2019-09-25 21:14:27'
updated: '2019-09-25 21:17:40'
tags: [Linux, Debian, frp]
permalink: /articles/2019/09/25/1569417267545.html
---
#  强大的Frp

最近在需要在外网防火墙不开放端口的情况下，能访问到公司或客户内网网络中HTTP服务与SSH远程到服务器主机上。经过测试GitHub上的Frp很稳定的解决我的需求。

frp 是一个可用于内网穿透的高性能的反向代理应用，支持 tcp, udp 协议，为 http 和 https 应用协议提供了额外的能力，且尝试性支持了点对点穿透。

# 使用示例

根据对应的操作系统及架构，从[发布](https://github.com/fatedier/frp/releases)页面下载最新版本的程序。

### 通过ssh访问公司内网机器

1. 修改frps.ini文件，这里使用了最简化的配置：

```
# frps.ini
[common]
bind_port = 7000
```

2.启动frps:
`./frps -c ./frps.ini`

3.修改frpc.ini文件，假设frps所在服务器的公网IP为49.xxx.xxx.xxx
```
#frpc.ini
[common]
server_addr = 49.xxx.xxx.xxx
server_port = 7000

[ssh]
type = tcp
local_ip = 127.0.0.1
local_port = 22
remote_port = 6000
```

4.启动frpc:
`./frpc -c ./frpc.ini`

5.通过ssh访问内网机器，假设用户名为test:
`ssh -oProt=6000 test@49.xxx.xxx.xxx`

### 通过自定义域名访问部署于内网的 web 服务

有时想要让其他人通过域名访问或者测试我们在本地搭建的web服务，但是由于本机机器没有公网IP，无法将域名解析到本地的机器，通过frp就可以实现这一功能，以下示例为HTTP服务，HTTPS服务配置方法相同，vhost_http_port替换为vhost_https_port，type设置为https即可。

1.修改frps.ini文件，设置http访问端口为8080：
```
# frps.ini
[common]
bind_port = 7000
vhost_http_port = 8080
```

2.启动frps：
`./frps -c ./frps.ini`

3.修改frpc.ini文件，假设frps所在的服务器的IP为49.xxx.xxx.xxx，local_port为本地机器上web服务对应的端口，帮定自定义域名`www.loonghoo.cn`:

```
# frpc.ini
[common]
server_addr = 49.xxx.xxx.xxx
server_port = 7000

[web]
type = http
local_port = 80
custom_domains = www.loonghoo.cn
```

4.启动frpc:
`./frpc -c ./frpc.ini

5.将`www.loonghoo.cn`的域名A记录解析到`49.xxx.xxx.xxx`,如果服务器已经有对应的域名，也可以将CNAME记录解析到服务器原先的域名。

6.通过浏览器访问`www.loonghoo.cn:8080`即可访问到处于内网机器上的web服务。

### 想学习详细的frp的知识和技术

请访问[frp中文文档](https://github.com/fatedier/frp/blob/master/README_zh.md)

### frp开机自启

* **以下将frp配置为系统服务，让frps\frpc可以开机自启。**

1.配置`/lib/systemd/system/frps.service`
```
vim /lib/systemd/system/frps.service
```
写入以下配置：
```
[Unit]
Description=Frp Server Service
After=network.target

[Service]
Type=simple
User=nobody
Restart=on-failure
RestartSec=5s
ExecStart=/usr/frp/frps -c /usr/frp/frps.ini

[Install]
WantedBy=multi-user.target
```
然后启动frps：

```
systemctl start frps
```

查看frps运行日志

```
systemctl status frps
```

设置开启自启

```
systemctl enable frps ###开启自启
systemctl restart frps ###重启
systemctl stop frps ###停止
```

* **第二种配置方式： rc.local 服务**

Debian 9 默认不带 /etc/rc.local 文件，而 rc.local 服务却还是自带的。

```
root@debian9 ~ # cat /lib/systemd/system/rc.local.service
#  This file is part of systemd.
#
#  systemd is free software; you can redistribute it and/or modify it
#  under the terms of the GNU Lesser General Public License as published by
#  the Free Software Foundation; either version 2.1 of the License, or
#  (at your option) any later version.

# This unit gets pulled automatically into multi-user.target by
# systemd-rc-local-generator if /etc/rc.local is executable.
[Unit]
Description=/etc/rc.local Compatibility
ConditionFileIsExecutable=/etc/rc.local
After=network.target

[Service]
Type=forking
ExecStart=/etc/rc.local start
TimeoutSec=0
RemainAfterExit=yes
GuessMainPID=no
```

并且默认情况下这个服务还是关闭的状态

```
root@debian9 ~ # systemctl status rc-local
● rc-local.service - /etc/rc.local Compatibility
   Loaded: loaded (/lib/systemd/system/rc-local.service; static; vendor preset: enabled)
  Drop-In: /lib/systemd/system/rc-local.service.d
           └─debian.conf
   Active: inactive (dead)
```

我们需要手工添加一个 /etc/rc.local 文件

```
cat <<EOF >/etc/rc.local
#!/bin/sh -e
#
# rc.local
#
# This script is executed at the end of each multiuser runlevel.
# Make sure that the script will "exit 0" on success or any other
# value on error.
#
# In order to enable or disable this script just change the execution
# bits.
#
# By default this script does nothing.

exit 0
EOF
```

赋予权限与启动rc-local服务

```
chmod +x /etc/rc.local
systemctl start rc-local
```

再次查看状态

```
root@debian9 ~ # systemctl status rc-local
● rc-local.service - /etc/rc.local Compatibility
   Loaded: loaded (/lib/systemd/system/rc-local.service; static; vendor preset: enabled)
  Drop-In: /lib/systemd/system/rc-local.service.d
           └─debian.conf
   Active: active (exited) since Thu 2017-08-03 09:41:18 UTC; 14s ago
  Process: 20901 ExecStart=/etc/rc.local start (code=exited, status=0/SUCCESS)

Aug 03 09:41:18 xtom-proxy systemd[1]: Starting /etc/rc.local Compatibility...
Aug 03 09:41:18 xtom-proxy systemd[1]: Started /etc/rc.local Compatibility.
```

然后你就可以把需要开机启动的命令添加到 /etc/rc.local 文件，丢在 exit 0 前面即可，并尝试重启以后试试是否生效了
