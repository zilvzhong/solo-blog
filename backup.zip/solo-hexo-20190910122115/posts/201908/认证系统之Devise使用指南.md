title: 认证系统之Devise使用指南
date: '2019-08-29 12:11:15'
updated: '2019-08-29 12:11:15'
tags: [Rails]
permalink: /articles/2019/08/29/1567051875898.html
---
## devise是什么？

devise是一个gem，一个包含用户登录注册系统的gem，用来就可以来轻易创建登录注册系统，而不用你再去重写一套登录逻辑，它很简单，很快就能使用起来。它会指引你创建相关的数据表，创建view，生成route，所有的一切它都会帮你完成，你只需要按照官方的readme文件简单操作几下就好了。5分钟内就可以实现一个登录注册系统。

# devise安装和使用

## **1.安装**

* 添加```gem 'devise'```至Gemfile

-运行```bundle install```
-运行```rails generate devise:install```安装devise相关组件

安装完提示如下：

```
Some setup you must do manually if you haven't yet:

  1. Ensure you have defined default url options in your environments files. Here
     is an example of default_url_options appropriate for a development environment
     in config/environments/development.rb:

       config.action_mailer.default_url_options = { host: 'localhost', port: 3000 }

     In production, :host should be set to the actual host of your application.

  2. Ensure you have defined root_url to *something* in your config/routes.rb.
     For example:

       root to: "home#index"

  3. Ensure you have flash messages in app/views/layouts/application.html.erb.
     For example:

       <p class="notice"><%= notice %></p>
       <p class="alert"><%= alert %></p>

  4. If you are deploying on Heroku with Rails 3.2 only, you may want to set:

       config.assets.initialize_on_precompile = false

     On config/application.rb forcing your application to not access the DB
     or load models when precompiling your assets.

  5. You can copy Devise views (for customization) to your app by running:

       rails g devise:views

```

按照提示完成设置

-运行```rails g devise MODEL```生成需要用到devise的模型，路由中会自动生成一个devise_for :users。

（MODEL可以替换成user, admin等，一般来说你就写成user就好了，但是有些情况下是这样的，你可能给你的客户一套登录系统，就存在users表就好了，但是你有很多员工，员工需要登录后台，有时候为了方便 ，这两个系统是需要分开的，这个时候，你可能需要多一套登录系统，那就是叫admin好了，员工的登录数据会存在admins表中，当然，名字是人定的，上面只不过是举个例子，简单说明一下。)

- 执行```rake db:migrate```迁移文件生成数据表

（上面的工作做的是安装，生成数据表，生成routes，控制器，action之类也是devise给你写好的。view也是有默认给你写好的。）

## **2.使用**

- 第一步，肯定是添加注册框，注销框等，注册之后有账号才能登录呀。注册框在哪，需要路由地址吧。我们不用写了，devise帮我们生成好了。你运行```rake routes``` 就可以看到了。

```
<% if user_signed_in? %>
  <%= link_to('注销', destroy_user_session_path, :method => :delete) %>
<% else %>
  <%= link_to('注册', new_registration_path(:user)) %>
  <%= link_to('登录', new_session_path(:user)) %>
<% end %>

```

- 在控制器中，设置访问之前需要先登录

```
before_action :authenticate_user!
```

(devise会创建以下方法：
before_action :authenticate_user! //建立一个控制器使用devise用户身份验证

user_signed_in? //判断用户是否登录

current_user //获取当前登录用户

user_session //可以访问对应的session)

**自定义登录字段，devise默认使用emails登录，在此添加username登录字段**

1.添加username字段
-执行```rails generate migration add_username_to_users username:string```，
-执行```rake db:migrate```


2.在```config/initializers/devise.rb```中配置登录验证的字段:

```
config.authentication_keys = [:username]
config.case_insensitive_keys = [:username]
config.strip_whitespace_keys = [:username]

```

3.修改完字段后，对应的去修改views里面的视图，把登录页面的email字段改成username，在注册页面新加上username的input

```
<%= f.label :username %> 
<%= f.text_field :username %>

```

4.修改完之后，接下来需要重写一个方法，用来配置登录和注册所允许的参数，将此方法写在application_controller.rb中

```
def configure_permitted_parametersod_name
    devise_parameter_sanitizer.permit(:sign_in) {|u|               u.permit(:email, :username)}
    devise_parameter_sanitizer.permit(:sign_up) {|u|
    u.permit(:email, :username, :password,                      :password_confirmation)}
end

```

5.在application_controller.rb还需要配置(否则注册时，会出现邮箱验证不通过的BUG)

```
before_action :configure_permitted_parametersod_name, if: :devise_controller?

```

此时即可使用username登录了

**如果想devise使用用户名或邮箱都可以登录**

1.需要在user模型里加入一个虚拟属性：
```attr_accessor :signin```
然后在/config/ initializers/devise.rb中修改验证参数

```
config.authentication_keys = [ :signin ]
```

2.修改了验证参数之后，需要去模型里面重写登录devise会使用到的方法,在user.rb里面重写self.find_for_database_authentication方法

```
def self.find_for_database_authentication(warden_conditions)
    conditions = warden_conditions.dup
    if signin = conditions.delete(:signin)
      where(conditions.to_h).where(["lower(username) = :value OR lower(email) = :value", { :value => signin.downcase }]).first
    elsif conditions.has_key?(:username) || conditions.has_key?(:email)
      where(conditions.to_h).first
    end
end

```

3.在模型里定义完方法之后，需要将application_controller.rb中那个允许参数的方法重写

```
 def configure_permitted_parametersod_name
    devise_parameter_sanitizer.permit(:sign_in) {|u| u.permit(:signin, :password, :remember_me)}
    devise_parameter_sanitizer.permit(:sign_up) {|u|
    u.permit(:email, :username, :password, :password_confirmation)}
  end
  
```

4.去登录视图中，将username的input改成signin的input,这样一来，用用户名和邮箱都可以实现登录功能

```
<%= f.label :signin %></br>
<%= f.text_field :signin  %>

```

**定制devise错误提示信息**

Dvise处理错误信息的方式是把所有需要的信息都用i18n的方式保存在config/local/devise.en.yml文件中,这样就很容易修改。

```
    #/config/locales/devise.en.yml  
    en:    
      errors:    
        messages:    
          not_found: "not found"    
          already_confirmed: "was already confirmed"    
          not_locked: "was not locked"    
        
      devise:    
        failure:    
              unauthenticated: 'You need to sign in or sign up before continuing.'    
              unconfirmed: 'You have to confirm your account before continuing.'    
              locked: 'Your account is locked.'    
              invalid: 'OH NOES! ERROR IN TEH EMAIL!'    
              invalid_token: 'Invalid authentication token.'    
              timeout: 'Your session expired, please sign in again to continue.'    
              inactive: 'Your account was not activated yet.'    
            sessions:    
              signed_in: 'Signed in successfully.'    
              signed_out: 'Signed out successfully.'    
        #rest of file omitted.  
        
```

关于devise的使用方法，上面只是做了简单的介绍。具体的还是要去仔细阅读官方的文档。[点我吧](https://github.com/plataformatec/devise)