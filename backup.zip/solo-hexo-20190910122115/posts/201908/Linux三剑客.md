title: Linux三剑客
date: '2019-08-29 12:11:02'
updated: '2019-08-29 12:11:02'
tags: [Linux]
permalink: /articles/2019/08/29/1567051862504.html
---
## sed


>sed被称作流编辑器(stream editor)，和普通的交互式文本编辑器恰好相反。在交互式 文本编辑器中(比如vim)，你可以用键盘命令来交互式地插入、删除或替换数据中的文本。流编辑器则会在编辑器处理数据之前基于预先提供的一组规则来编辑数据流。

* 处理流程

1. 一次从输入中读取一行数据。

1. 根据所提供的编辑器命令匹配数据

1. 按照命令修改流中的数据。

1. 将新的数据输出到STDOUT。

* 格式

    ` sed options script file`
    

| options                    | 描述                                             |
|:------------------------|:-------------------------------                     |
| -e  script              | 多点编辑                                            |
| -f file                 | /PATH/SCRIPT_FILE: 从指定文件中读取编辑脚本         |
| -n                      | 不输出模式空间内容到屏幕，即不自动打印              |
| -r                      | 支持使用扩展正则表达式                              |
| -i.bak                  | 备份文件并原处编辑                                  |

| 编辑命令（script）                  | 描述                                             |
|:------------------------|:-------------------------------                     |
| d                       | 删除模式空间匹配的行，并立即启用下一轮循环                                   |
| p                   | 打印当前模式空间内容，追加到默认输出之后     |
| a\text                      | 在指定行后面追加文本              |
| i\text                       | 在指定行后面追加文本                             |
| c\text                   | 替换行为单行或多行文本                                  |


* 列子


```
➜$ > echo "This is a bug\nThis is a bug\nThis is a bug"  > data.txt

➜$ > sed -e 's/a/not a/; s/bug/apple/' data.txt
This is not a apple
This is not a apple
This is not a apple

➜$ > echo "This is brown\nThis is fox\nThis is dog" >data1.txt

➜$ >cat >>script.sed
s/brown/green/
s/fox/elephant/
s/dog/cat/

➜$ > sed -f script.sed data1.txt
This is green
This is elephant
This is cat

```

* 替换标记

有4种可用的替换标记:
>数字，表明新文本将替换第几处模式匹配的地方; 

>g，表明新文本将会替换所有匹配的文本;

>p，表明原先行的内容要打印出来;

>w file，将替换的结果写到文件中。

```
### 数字 

$ echo "This is a test of the trial script.\nThis is the second test of the trial script" > data.txt


$ sed 's/test/trial/2' data.txt 
#只替换每行中第二次出现的匹配模式
This is a test of the trial script.
This is the second test of the trial script

### g 

$ sed 's/test/trial/g' data.txt
#g替换标 记使你能替换文本中匹配模式所匹配的每处地方。
This is a trial of the trial script.
This is the second trial of the trial script.

### p

注p替换标记会打印与替换命令中指定的模式匹配的行。这通常会和sed的-n选项一起使用

sed -n '1s/test/trial/p' data.txt
#p替换标记会打印与替换命令中指定的模式匹配的行。
This is a trial of the trial script.


### w

sed 's/test/trial/w test.txt' data.txt
#w替换标记会产生同样的输出，不过会将输出保存到指定文件中。

```

* 替换字符

>替换文件中的路径名会比较麻烦。比如，如果想用替换/etc/passwd文件中的bash shell， 必须这么做:  
`$ sed 's/\/bin\/bash/\/bin\/csh/' /etc/passwd`

>要解决这个问题，sed编辑器允许选择其他字符来作为替换命令中的字符串分隔符:     
`$ sed 's!/bin/bash!/bin/csh!' /etc/passwd`

* sed 示例
```

sed '2p' /etc/passwd
sed -n '2p' /etc/passwd
sed -n '1,4p' /etc/passwd
sed -n '/root/p' /etc/passwd
sed -n '2,/root/p' /etc/passwd 从2行开始
sed -n '/^$/=' file 显示空行行号
sed –n –e '/^$/p' –e '/^$/='' file
sed '/root/a\superman' /etc/passwd行后 
sed '/root/i\superman' /etc/passwd 行前 
sed '/root/c\superman' /etc/passwd 代替行

sed ‘/^$/d’ file
sed ‘1,10d’ file
nl /etc/passwd | sed ‘2,5d’
nl /etc/passwd | sed ‘2a tea’
sed 's/test/mytest/g' example
sed –n ‘s/root/&superman/p’ /etc/passwd 单词后 
sed –n ‘s/root/superman&/p’ /etc/passwd 单词前 
sed -e ‘s/dog/cat/’ -e ‘s/hi/lo/’ pets
sed –i.bak ‘s/dog/cat/g’ pets

```

## grep

> grep命令是一种强大的文本搜索工具，它能使用正则表达式搜索文本，并把匹 配的行打印出来。grep全称是Global Regular Expression Print，表示全局正则表达式版本。

* 格式

    `grep [options] pattern [flie-list]`

grep可以在一个或多个文件中按行搜索pattern。其中，pattern可以是一个简单的字符串，也可以是另一种形式的正则表达式。实用程序grep根据指定的选项采取各种各样的动作，查找包含于pattern匹配的字符串的行。


| 选项                      | 描述                                          |
|:------------------------  |:-------------------------------               |
| -v                        | 显示不被pattern匹配到的行                     |
| -i                        | 显示不被pattern匹配到的行                     |
| -n                        | 显示匹配的行号                                |
| -c                        | 统计匹配的行数                                |
| -q                        | 仅显示匹配到的字符串                          |
| -A                        | after, 后#行                                  |
| -B                        | before, 前#行                                 |
| -C                        | context, 前后各#行                            |
| -E                        | 相当实用egrep                                 |
| -e                        | 实现多个选项间的逻辑or关系                    |
| -w                        | 仅显示匹配到的字符串                          |


##