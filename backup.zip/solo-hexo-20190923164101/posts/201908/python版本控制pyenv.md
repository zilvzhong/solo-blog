title: python 版本控制pyenv
date: '2019-08-29 12:11:15'
updated: '2019-08-29 12:11:15'
tags: [Python]
permalink: /articles/2019/08/29/1567051875681.html
---
### 简单的Python版本管理：pyenv
    
pyenv可让您轻松切换多个版本的Python。它简单，不引人注目，并且遵循单一用途工具的UNIX传统，它做得很好。这个项目是从rbenv和 ruby-build分支出来的，并为Python修改过。

### pyenv的作用

* 让您基于每个用户更改全局Python版本。
* 为每个项目的Python版本提供支持。
* 允许您使用环境变量覆盖Python版本。
* 一次从多个版本的Python中搜索命令。这可能有助于使用tox测试Python版本。

    
    
    
    
#### 如何安装pyenv

懒人使用：[自动安装脚本](https://github.com/pyenv/pyenv-installer)


1、使用Homebrew 软件包管理器为macOS 安装[pyenv](https://github.com/pyenv/pyenv#basic-github-checkout)

```
1、# https://brew.sh/ 
# 执行如下命令安装Homebrew

/usr/bin/ruby -e "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/master/install)"
brew install pyenv


2、#已安装了brew,update更新后再进行安装
brew update
brew install pyenv

3、#安装pyenv-virtualenv
brew install pyenv-virtualenv

4、#Add pyenv init to your shell
echo -e 'if command -v pyenv 1>/dev/null 2>&1; then\n  eval "$(pyenv init -)"\nfi' >> ~/.bash_profile

#Zsh note: Modify your ~/.zshenv file instead of ~/.bash_profile
```



#### pyenv常用命令

| commands                    | 作用                                |
|:------------------------|:-------------------------------         |
| local                   | 设置或显示本地特定应用程序的python版本  |
| global                  | 设置或显示全局python版本                |
| shell                   | 设置或显示特定shell的python版本         |
| install                 | 使用python-build安装python版本          |
| uninstall               | 卸载特定的Python版本                    |
| rehash                  | 重新散列pyenv shims(在安装可执行文件后运行)|
| version                 | 显示当前Python版本                      |
| versions                | 列出pyenv可用的所有Python版本           |
| which                   | 显示可执行文件的完整路径                |
| whence                  | 列出所有包含给定可执行文件的Python版本  |

  
![](/images/posts/linux/pyenv.jpg)


##### 常见问题

[pyenv安装python常见问题](https://github.com/pyenv/pyenv/wiki/Common-build-problems#build-failed-error-the-python-zlib-extension-was-not-compiled-missing-the-zlib)

1、Build failed: "ERROR: The Python zlib extension was not compiled. Missing the zlib?"

解决：
```
xcode-select --install
sudo installer -pkg /Library/Developer/CommandLineTools/Packages/macOS_SDK_headers_for_macOS_10.14.pkg -target /
```