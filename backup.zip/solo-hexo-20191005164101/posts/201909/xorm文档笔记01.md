title: xorm文档笔记-01
date: '2019-09-19 18:33:43'
updated: '2019-09-19 20:58:33'
tags: [Go, 数据库]
permalink: /articles/2019/09/19/1568889223503.html
---
# xorm

xorm是一个简单而强大的Go语言ORM库，通过它可以使数据可操作非常简便。xorm的目标并不是让你完全不去学习SQL，我们认为SQL并不会为ORM所替代。但是ORM将可以解决绝大部分的简单SQL需求。xorm支持两种风格的混用。

# 特性

* 支持Struct和数据库表之间的灵活映射，并支持自动同步表结构。

* 事务支出

* 支持原始SQL语句和ORM操作的混合执行

* 使用连写来简化调用

* 支持使用ld,ln,Where,Limit,Join,Having,Table,Sql,Cols等函数和结构体等方式作为条件

* 支持级联加载Struct

* 支持LRU缓存(支持memory, memcache, leveldb, redis缓存Store) 和 Redis缓存
    
* 支持反转，即根据数据库自动生成xorm的结构体
    
* 支持事件
    
* 支持created, updated, deleted和version记录版本（即乐观锁）

## 驱动支持

xorm当前支持的驱动和数据库如下：

* Mysql: [github.com/go-sql-driver/mysql](https://github.com/go-sql-driver/mysql)
    
* MyMysql: [github.com/ziutek/mymysql/godrv](https://github.com/ziutek/mymysql/godrv)
    
* Postgres: [github.com/lib/pq](https://github.com/lib/pq)
    
* Tidb: [github.com/pingcap/tidb](https://github.com/pingcap/tidb)
    
* SQLite: [github.com/mattn/go-sqlite3](https://github.com/mattn/go-sqlite3)
    
* MsSql: [github.com/denisenkom/go-mssqldb](https://github.com/denisenkom/go-mssqldb)
    
* MsSql: [github.com/lunny/godbc](https://github.com/lunny/godbc)
    
* Oracle: [github.com/mattn/go-oci8](https://github.com/mattn/go-oci8) (试验性支持)
    
* ql: [github.com/cznic/ql](https://github.com/cznic/ql) (试验性支持)

# 安装

```
go get -u github.com/go-sql-driver/mysql
gopm get github.com/go-xorm/xorm
```
或者您也可以使用go工具进行安装：
```
go get -u github.com/go-sql-driver/mysql
go get github.com/go-xorm/xorm
```

# 创建Orm引擎

在xorm里面，可用同时存在多个Orm引擎，一个Orm称为Engine，一个Engine一半只对应一个数据库。Engine通过调用`xorm.NewEngine`生成，如：

```
import (
	_ "github.com/go-sql-driver/mysql"
	"github.com/go-xorm/xorm"
)

var engine *xorm.Engine

func main() {
	var err error
//	engine, err = xorm.NewEngine("mysql", "root:123@/test?charset=utf8")
	engine, err = xorm.NewEngine("mysql", "root@123.com@tcp(127.0.0.1:3306)/s002?charset=utf8")
}
```

or

```
import (
	_ "github.com/mattn/go-sqlite3"
	"github.com/go-xorm-xorm"
)

var engine *xorm.Engine

func main() {
	var err error
	engine, err = xorm.NewEngine("sqlite3", "./test.db")
}
```
一般情况下如果只操作一个数据库，只需要创建一个`Engine`即可，Engine是GoRoutine安全的。

创建完成`engine`之后，并没有立即连接数据库，此时可以通过`engine.Ping()`来进行数据库的连接测试是否可以连接到数据库。另外对于某些数据库有连接超时设置的，可以通过起一个定期Ping的Go程序来保持连接。Engine可以通过engine.Close来手动关闭，但是一般情况下可以不用关闭，在程序退出时会自动关闭。**如有日志以及连接池的问题——[点击查看这](http://gobook.io/read/github.com/go-xorm/manual-zh-CN/chapter-01/)**

# 定义表结构体
xorm支持将一个Struct映射为数据库中对应的一张表，映射规则如下：

* **名称映射规则：**
>> 名称映射规则主要负责结构体名称到表名和结构体field到表字段的名称映射。由code.IMapper接口的实现者来管理，xorm内置了三种IMapper实现：`core.SnakeMapper`,`core.SameMapper`和`core.GonicMapper`。*SameMapper支持Struct为驼峰式命名，表结构为下划线命名之间的转换，这个是默认的maper；*SameMapper支持结构体名称和对应的表名称以及结构体field名称与对应的表字段名称相同的命名；*GonicMapper和SnakeMapper很类似，但是对于特定词支持更好，比如ID会翻译为id而不是i_d。

```
#但前SnakeMapper为默认值，如果需要改变时，在engine创建完成后使用
engine.SetMapper(core.SameMapper{})

#如果你使用了别的命名规则映射方案，也可以自己实现一个lMapper.
#表名称和字段名称的映射规则默认是相同的，当然也可以设置为不同，如：
engine.SetTableMapper(core.SameMapper{})
engine.SetColumnMapper(core.SnakeMapper{})
```

* **前缀映射，后缀映射和缓存映射**
>> 1.  通过`core.NewPrefixMapper(core.SnakeMapper{}, "prefix")`可以创建一个在SnakeMapper的基础上再命名中添加同一的前缀，当然也可以把SnakeMapper{}换成SameMapper或者你自定义的Mapper。
```  
#所有的表名都在结构体自动命名的基础上加一个前缀而字段名不加前缀，则可以在engine创建完成后执行以下语句：  
tbMapper := core.NewPrefixMapper(core.SnakeMapper{}, "prefix_")  
engine.SetTableMapper(tbMapper)  
  
执行之后，结构体type User struct默认对应的表名就变成prefix_user了，而之前默认的是user  
```
>> 2.  通过 `core.NewSufffixMapper(core.SnakeMapper{}, "suffix")` 可以创建一个在SnakeMapper的基础上在命名中添加统一的后缀，当然也可以把SnakeMapper换成SameMapper或者你自定义的Mapper。
>> 3.  通过 `core.NewCacheMapper(core.SnakeMapper{})` 可以创建一个组合了其它的映射规则，起到在内存中缓存曾经映射过的命名映射。

* **Column属性定义**
>> 我们在field对应的Tag中对Column的一些属性进行定义，定义的方法基本和我们写SQL定义表结构类似（查看具体的Tag规则，[请点击这](http://gobook.io/read/github.com/go-xorm/manual-zh-CN/chapter-02/4.columns.html)），比如：
```
type User struct {
	Id		int64
	Name 		string `xorm:"varchar(25) notnull unique 'usr_name'"`
}
* 如果field名称为Id而且类型为int64并且没有定义tag,则会被xorm视为主键，并且拥有自增属性。如果想用Id以外的名字或非int64类型作为主键名，必须在对应的Tag上加上`xorm:"pk"`来定义主键，加上xorm:"autoincr"作为自增。这里需要注意的是，有些数据库并不允许非主键的自增属性。

* string类型默认映射为varchar(255),如果需要不同的定义，可以在tag自定义。

* 支持type MyString string等自定义field，支持Slice，Map等field成员，这些成员默认存储为Text类型，并且默认将使用json格式来序列化和反序列化。如果是Blob类型，则先使用json格式化序列化再转成[]byte格式。
```

* **Go与字段类型对应表**
>> 如果不使用tag来定义field对应的数据库字段类型，那么系统会自动给出一个默认的字段类型，对应表详细请点击[这里](http://gobook.io/read/github.com/go-xorm/manual-zh-CN/chapter-02/5.types.html)

# 表结构操作

* **获取数据库信息**
>> `DBMetas()`: xorm支持获取表结构信息，通过调用engine.DBMetas()可以获取到数据库中所有的表，字段，索引的信息。
>> `Tablelnfo()`:根据传入的结构体指针及其对应的tag，提取出模型对应的表结构信息，这里不是数据库当前的表结构信息，而是我们通过struct建模时希望数据库的表的结构信息。

* **表操作**
>> 1、`CreateTables()`:创建表使用engine.CreateTables(),参数为一个或多个空的对应Struct的指针，同时可用的方法有Charset()和StoreEngine()，如果对应的数据库支持，这两个方法可以在创建表时指定表的字符编码和使用的引擎。Charset()和StoreEngine()当前仅支持MySQL数据库。
>> 2、`IsTableEmpty()`:判断表是否为空，参数和CreateTables相同。
>>3、`IsTableExist()`:判断表是否存在
>>4、`DropTables()`:删除表使用engine.DropTables(),参数为一个或多个空的对应Struct的指针或表的名字。如果为string传入，则只删除对应的表，如果传入的为Struct，则删除表的同时还会删除对应的索引。

* **创建索引和唯一索引**
>> 1、`CreateIndexes`:根据struct中的tag来创建索引
>> 2、`CreateUniques`:根据struct中的tag来创建唯一索引

* **同步数据库结构**
>> 同步能够部分智能的根据结构体的变动监测表结构的变动，并自动同步，目前有两个实现：

>>> 1、`Sync`: 自动检测和创建表，这个检测是根据表的名字、自动检测和新增表中的字段，这个检测是根据字段名、自动检测和创建索引和唯一索引，这个检测是根据索引的一个或多个字段名，而不是根据索引名称。
>>> 2、`Sync2`: 自动检测和创建表，这个检测是根据表的名字、自动检测和新增表中的字段，这个检测是根据字段名，同时对表中多余的字段给出警告信息、自动检测，创建和删除索引和唯一索引，这个检测是根据索引的一个或多个字段名，而不是根据索引名称，因此这里需要注意，如果在一个有大量数据的表中引入新的索引，数据库可能需要一定的时间来建立索引、自动转换varchar字段类型到Text字段类型，自动警告其他字段类型在模型和数据库之间不一致的情况、自动警告字段的默认值，是否为空信息在模型和数据库之间不匹配的情况。（这些警告信息需要将`engine.ShowWarn`设置为`true`才会显示。)
```
#调用方法和Sync一样：
err := engine.Sync2(new(User), new(Group))
```

* **导入导出SQL脚本**
>> 1、如果需要在程序中Dump数据库的结构和数据可以调用`engine.DumpAll(w io.Writer)`和`engine.DumpAllFile(fpath string)`。
>> 2、如果你需要将保存在文件或者其他存储设施中的SQL脚本执行，那么可以调用`engine.Import(r io.Reader)`和`engine.ImportFile(fpath string)`
