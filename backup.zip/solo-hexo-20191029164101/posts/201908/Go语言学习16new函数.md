title: Go语言学习16_new函数
date: '2019-08-29 12:11:15'
updated: '2019-08-29 17:12:38'
tags: [Go]
permalink: /articles/2019/08/29/1567051875210.html
---
# 一.new函数

* 在学习了指针,每次创建一个指针必须在额外创建一个变量,操作比较麻烦.
* 可以通过new函数直接创建一个类型的指针```变量名:=new(Type)```

* 使用new函数创建的指针已有指向,可以使用`*指针对象`进行赋值.

```go
func main() {
	a := new(int)
	fmt.Println(a) //输出:指针地址
	*a = 123
	fmt.Println(*a) //输出:123
}
```
* 只声明的指针变量不能直接赋值,

```go
func main() {
	var a *int
	*a = 123
	fmt.Println(*a)
}
```
* 结果
```
panic: runtime error: invalid memory address or nil pointer dereference
[signal 0xc0000005 code=0x1 addr=0x0 pc=0x48b576]
```
