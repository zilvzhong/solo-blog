title: will_paginate使用指南
date: '2019-08-29 12:11:10'
updated: '2019-08-29 12:11:10'
tags: [Rails]
permalink: /articles/2019/08/29/1567051870950.html
---
在ruby中分页有两个比较知名的gems：will_paginate和kaminari。本文主要通过一个列子来讲述在rails中如何使用[will_paginate](https://github.com/mislav/will_paginate)来进行分页，以及will_paginate的一些常用参数和自定义等。

## 一、安装will_paginate

* 编辑GemFile，添加：```gem 'will_paginate'

-执行```bundle install```
会自动下载安装最新版本will_paginate

## 二、配置will_paginate

* 修改要进行分页的Controller,在index方法中把旧的查找全部的方法改为:

```
# @posts = Post.all
@posts = Post.paginate
             (:page => params[:page], :per_page => 20)
             
```

-params[:page]是传回的参数，表明是第几页；

-:per_page是每页显示几条信息；

* 修改index对应的视图

-在结尾添加```<% will_paginate @posts %>```
至此，分页完成。

## 三、分页风格设置

* 我们可以通过添加一些CSS样式，使分页链接漂亮些，
官方有提供了一些相对美观的分页样式（[点我去查看吧](http://mislav.github.io/will_paginate/)）。下面我们把分页式改为Flickr.com的式。

-下载css样式并将其放至```app/assets/stylessheets/```目录下

```
wget http://mislav.uniqpath.com/will_paginate/pagination.css
```

-编辑```app/assets/stylesheets/application.css ```，添加```*= require pagination```引入css。

-最后编辑index.html.erb文件，添加以下code:

```
<div class="flickr_pagination">
       <div class="page_info">
           <%= page_entries_info @posts %>
       </div>
       <%= will_paginate @posts, :container => false %>
    </div>
    
```

-class="flickr_pagination" 指明了要使用的式

-:container => false 指明了不要自动生成最外层的

完成！分页漂亮多了。