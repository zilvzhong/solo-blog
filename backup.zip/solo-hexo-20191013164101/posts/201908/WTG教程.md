title: WTG教程
date: '2019-08-29 12:11:09'
updated: '2019-08-29 12:11:09'
tags: [Mac]
permalink: /articles/2019/08/29/1567051869976.html
---
## 前言
我在使用MacBook Pro或iMac的过程中，基于种种原因会有使用Windows的需求，虚拟机上的Windows体验并不好。而WTG可以完美满足我的这个需求——将win10装入移动硬盘，在开机启动时选择启动的磁盘即可。

> 其优点：

>> 1、整个Windows系统在移动硬盘中与本机无任何关系，只是共用一套硬件。

>> 2、性能上和一般Windows笔记本无太大区别十分流畅使用。

> 其缺点：
>> 1、占用一个宝贵的 USB 接口

>> 2、WTG 系统下是无法访问本机硬盘的，但是在 OS X 系统下可以读取 WTG 硬盘的内容，但不能写入（安装软件例如Mounty之类的可以写入。

>> 3、不能设置每次开机自动从 WTG 系统启动，所以系统不能重启，不能休眠。

>>4、 不能在 WTG 系统下升级系统。


## Windows To Go详解：

> Windows To Go是Windows 8/8.1、Windows 10的一种企业功能，被内置于Windows 8企业版、Windows 8.1企业版、Windows 10企业版、教育版与专业版（1607以后）中。对于满足Windows 8硬件要求的电脑，Windows To Go可使Windows 8、Windows 8.1、Windows10从USB驱动器中启动并运行，不必考虑电脑上运行的操作系统（2012款之前的Mac和Windows RT不被支持）。

> 在列举说下除了WTG外其他三种满足Mac用户使用Windows需求的方案

>>方案一（苹果官方提供）：使用Mac中的启动转换助理Boot Camp 将本机固态内存划分一部分给Windows使用。
优点：1、官方方法，可靠性高。2、安装简便。3、安装完的Windows可以正常使用所有功能（包括自动更新）4、可以设置默认启动系统。5、使用本机固态，尊享飞一般读取的速度。
缺点：1、占用我贫瘠的本机固态空间。（一点足以致命，对于128g版而言）

>>方案二：跑虚拟机，使用VMware Fusion或Parallels Desktop等虚拟机软件。优点：1、可以同时使用Mac os与windows。 缺点：1、占用我贫瘠的本机固态空间。（是的又是我）2、性能占用高。3、貌似虚拟机软件得付费吧？

>>方法三：买一台win10笔记本或配一台高性能工作站（滑稽）。


### 让我们开始动手⑧


**准备：**



<table>
<tr>
   <th>软件</th>
   <th>硬件</th>
</tr>
<tr>
   <td>Windows镜像</td>
   <td>一台MacBook或iMac</td>
</tr>
<tr>
   <td>BootCamp驱动</td>
   <td>一台Windows10的PC</td>
</tr>
<tr>
  <td>WTG制作软件</td>
  <td>一块SSD和移动硬盘盒子</td>
</tr>
<tr>
  <td></td>
  <td>一个U盘</td>
</tr>
</table>
   
镜像和WTG下载：  [Windows镜像](https://msdn.itellyou.cn)和
[WTG软件](https://luobotou-singapore.oss-ap-southeast-1.aliyuncs.com/wtga4810.zip)。镜像可以选择multi-edition_version下载多版本的镜像。

BootCamp驱动下载：在Mac上打开"启动转换助手"在最上面的菜单中点击操作栏目，再点击下载Windows支持软件选择保存的位置，下载完成后的Windows support拷贝至U盘。

![](/images/posts/mac/boot.png)

**第一步：挂载镜像**

Windows10电脑双击镜像文件即可自动挂载，其他的Windows系统电脑需要下载个[虚拟光驱软件](http://www.downza.cn/soft/1802.html)

**第二步：插入移动硬盘**
不需要对移动硬盘做如何操作，只需要电脑可以识别到你的移动硬盘。

**第三步：使用WTG软件完成制作**

![](/images/posts/mac/wtg.jpg)

1、选择硬盘：选择你的移动硬盘，请勿选错。

2、选择镜像文件的install.wim文件。（点击浏览后进入挂载的虚拟光驱，再进入source文件就可以看到此文件）

3、高级设置
  * 在常用设置中选择VHD并勾选上UEFI+GPT（经过验证选择传统模式和xvhd模式不合适，传统模式出现了第二次启动win时无限卡在开机界面的情况，xvhhd模式我只做过一次，但后面系统还是崩溃了，具体原因不清楚是否和使用xvhd模式有关）
 
  ![](/images/posts/mac/wtgg.png)
  * 如果你下载的镜像是multi-edition_versio版本，在常用分卷中选择Windows10 Pro版本。如果不选择分卷则工具自动选择排列在第一个的镜像系统进行安装。
  * 在分区设置中设置硬盘分区。
  * 在VHD设置中虚拟硬盘大小即系统C盘的大小，不设置默认分配40G。（这里解释一下vhd模式，vhd模式是指在分区1下释放出一个c盘来，比如分区1有100个G，那么在系统开机是，c盘（比如40G）就从分区1中释放出来。）

  ![](/images/posts/mac/VHD.png)
  
  * 点击创建，耐心等待10-20分钟。
  
   ![](/images/posts/mac/wc.jpg)
  
   ![](/images/posts/mac/tj.jpg)

**第四步：进行Windows安装**

1、将你的Mac设备关机后，连接上移动硬盘。

2、按下开机键后立即按option键不放，即可选择启动硬盘,这里选择EFI Boot启动。如图：

![](/images/posts/mac/bois.jpg)

3、经过等待后进入Windows首次运行的设置，这时候你发现Mac的键盘触控板都用不了，这是正常的，因为还没有安装驱动。通过U盘将Windows support拷贝至Windows桌面，然后打开Windows support文件夹里面的BootCamp.exe文件进行驱动安装。（注意先不要联网，去关闭掉Windows自动更新）

**大功告成**
Windows激活工具

链接:https://pan.baidu.com/s/1tip8PlvAr_NYTY9WUHu2ZA  密码:mrom