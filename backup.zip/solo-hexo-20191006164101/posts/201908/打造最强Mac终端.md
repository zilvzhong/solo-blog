title: 打造最强Mac终端
date: '2019-08-29 12:11:12'
updated: '2019-08-29 12:11:12'
tags: [Mac]
permalink: /articles/2019/08/29/1567051872942.html
---
```打造Mac下最强终端：iTerm2 + oh my zsh +agnoster```
## 真正强大的shell：zsh

目前常用的Linux系统和OSX系统的默认Shell都是bash，但是真正强大的Shell是深藏不露的zsh，这货绝对是马车中的跑车，跑车中的飞行车，史称终极Shell，但是由于配置过于复杂，所以初期无人问津，很多人跑过来看看了zsh的配置，什么都不说转身就走。直到有一天，国外有个穷极无聊的程序员开发了一个能够让你快速上手的zsh项目，叫做oh my zsh，GitHub网址是：https://github.com/robbyrussell/oh-my-zsh。



# 终极Shell iTerm2 + oh my zsh +agnoster

### **1.安装iTerm2**

* iTerm2官方下载地址http://www.iterm2.com/downloads.html

### **2.安装Oh My Bash**
#### * 1.通过```cat /etc/shells```命令可以查看当前系统可以使用的shell。
```
# List of acceptable shells for chpass(1).
# Ftpd will not allow users to connect who are not using
# one of these shells.
/bin/bash
/bin/csh
/bin/ksh
/bin/sh
/bin/tcsh
/bin/zsh
/usr/local/bin/zsh
```
#### * 2.通过``` echo $SHELL``命令可以查看当前正在使用的shell。
```
# Mac系统中默认的shell为bash shell
/bin/zsh
```
#### * 3.如果当前的shell不是zsh，我们可以通过chsh -s /bin/zsh命令将其切换为zsh，终端重启之后即可生效。

#### * 4.将shell切换为zsh之后，我们就可以安装Oh My ZSH了
你可以使用curl或wget进行安装。

```
# curl 安装
sh -c "$(curl -fsSL https://raw.githubusercontent.com/robbyrussell/oh-my-zsh/master/tools/install.sh)"
# wget安装
sh -c "$(wget https://raw.githubusercontent.com/robbyrussell/oh-my-zsh/master/tools/install.sh -O -)"

```

![](/images/posts/mac/oh-my-zsh.png)
出现以上提示，便是安装成功。

#### * 5.配置agnoster主题
Oh My Zsh提供的所有主题在线预览：
https://github.com/robbyrussell/oh-my-zsh/wiki/Themes
安装成功之后，我们可以通过```vi ~/.zshrc```，设置ZSH_THEME="agnoster"对主题进行修改。并且再做一点点的改动：
```
PROMPT='%{$fg_bold[red]%}➜ %{$fg_bold[green]%}%p%{$fg[cyan]%}%d %{$fg_bold[blue]%}$(git_prompt_info)%{$fg_bold[blue]%}% %{$reset_color%}>'
#PROMPT='%{$fg_bold[red]%}➜ %{$fg_bold[green]%}%p %{$fg[cyan]%}%c %{$fg_bold[blue]%}$(git_prompt_info)%{$fg_bold[blue]%} % %{$reset_color%}'
```
对照原来的版本，我把 c 改为 d，c 表示当前目录，d 表示绝对路径，另外在末尾增加了一个「 > 」

#### * 6.插件
 oh my zsh 项目提供了完善的插件体系，相关的文件在~/.oh-my-zsh/plugins目录下，默认提供了100多种，大家可以根据自己的实际学习和工作环境采用，想了解每个插件的功能，只要打开相关目录下的 zsh 文件看一下就知道了。插件也是在.zshrc里配置，找到plugins关键字，你就可以加载自己的插件了，系统默认加载 git ，你可以在后面追加内容，如下：
```
plugins=(git textmate ruby autojump osx mvn gradle)
```
- 简单介绍几个：
  1、git：当你处于一个 git 受控的目录下时，Shell 会明确显示 「git」和 branch，如上图所示，另外对 git 很多命令进行了简化，例如 gco=’git checkout’、gd=’git diff’、gst=’git status’、g=’git’等等，熟练使用可以大大减少 git 的命令长度，命令内容可以参考~/.oh-my-zsh/plugins/git/git.plugin.zsh

- 2、textmate：mr可以创建 ruby 的框架项目，tm finename 可以用 textmate 打开指定文件。

- 3、osx：tab 增强，quick-look filename 可以直接预览文件，man-preview grep 可以生成 grep手册 的pdf 版本等。