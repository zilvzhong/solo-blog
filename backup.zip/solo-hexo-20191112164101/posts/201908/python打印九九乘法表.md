title: python 打印九九乘法表
date: '2019-08-29 12:11:11'
updated: '2019-08-29 12:11:11'
tags: [Python]
permalink: /articles/2019/08/29/1567051871138.html
---
## 循环它是让计算机自动完成重复工作的常见方式之一

本次通过练习打印九九乘法表来熟悉for循环。

### 一、Python的for循环

```
for variable in sequence:
    statements
else:
    statements
```

### 二、打印九九乘法表

##### 左下
```
for i in range(1,10):
    for y in range(1,i+1):
        print('{} + {} = {:2}'.format(y, i, y * i),end = '  ')
    print()
```

#####  左上
```
for i in range(1,10):
    for y in range(i,10):
        print('{} + {} = {:2}'.format(i, y, y * i),end = ' ')
    print('\n')
```

##### 右上
```
for i in range(1,10):
    for k in range(1,i):
        print('          ',end = ' ')
    for y in range(i,10):
        print('{} + {} = {:2}').format(i, y, y * i),end = ' ')
    print('\n')
```
##### 右下
```
for i in range(1,10):
    for k in range(1,10-i):
        print('           ',end = ' ')
    for y in range(1,i+1):
        print('{} + {} = {:2}'.format(y, i, y * i),end = '  ')
    print('\n')
```