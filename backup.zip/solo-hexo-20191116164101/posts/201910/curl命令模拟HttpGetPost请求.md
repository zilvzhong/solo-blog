title: curl命令模拟Http Get/Post请求
date: '2019-10-09 21:06:05'
updated: '2019-10-09 21:06:51'
tags: [Linux]
permalink: /articles/2019/10/09/1570626365727.html
---
### 什么是curl

curl命令是一个利用URL规则在命令行下工作的文件传输工具。它支持文件的上传和下载，所以是综合传输工具，但按传统，习惯称curl为下载工具。作为一款强力工具，curl支持包括HTTP、HTTPS、ftp等众多协议，还支持POST、cookies、认证、从指定偏移处下载部分文件、用户代理字符串、限速、文件大小、进度条等特征。做网页处理流程和数据检索自动化，curl可以祝一臂之力。


### curl 模拟 GET\POST 请求

在进行web后台程序开发测试过程中，常常会需要发送url进行测试，一般情况下，我们调试数据接口，都会使用一个 `postman` 、`Paw`等工具。但是实际上，我们在调试一些小功能的时候，完全没有必要使用它。在命令行中，我们使用 `curl` 这个工具，完全可以满足我们轻量的调试要求。使用curl可以方便地模拟出符合需求的url命令。

> * **curl Get请求**
curl命令  + 请求接口地址
**`curl localhost:3000/api/hosts`**

如上，我们就可以请求到我们的数据了，如果想看到详细的请求信息，我们可以加上 `-v` 参数

```
root@search:/opt/ssh-bridge#
root@search:/opt/ssh-bridge# curl localhost:3000/hosts -v
*   Trying ::1...
* TCP_NODELAY set
* Connected to localhost (::1) port 3000 (#0)
> GET /hosts HTTP/1.1
> Host: localhost:3000
> User-Agent: curl/7.52.1
> Accept: */*
>
< HTTP/1.1 200 OK
< Content-Type: application/json; charset=utf-8
< ETag: W/"fe1987afbdc85f8c8ffa125a5b5ea56b"
< Cache-Control: max-age=0, private, must-revalidate
< X-Request-Id: aaf78d58-246b-4f9f-8ae7-6ac0150f21db
< X-Runtime: 0.004669
< Transfer-Encoding: chunked
<
* Curl_http_done: called premature == 0
* Connection #0 to host localhost left intact
[{"id":1,"sn":"c528cc3c8eccf07d81cd5d18fd8c2927","model":"Webvpn","detail":"中戏","created_at":"2019-10-09T10:29:48.430Z","updated_at":"2019-10-09T10:33:58.427Z"},{"id":2,"sn":"c528cc3c8eccf07d81cd5d18fd8112","model":"Webvpn","detail":"中戏111","created_at":"2019-10-09T10:34:36.322Z","updated_at":"2019-10-09T10
```

> * **curl Post请求**
使用 `-X POST` 来申明我们的请求方法，用-H参数来申明请求的header，用 `-d` 参数，来传送我们的参数。
**`curl localhost:3000/hosts -X POST -d "sn=APCgCoDvvYT8fmVCHhCqdKrC&model=Tunnel&detail=Test"`**

同样可以使用-v来查询详情。
```
root@search:/opt/ssh-bridge# curl localhost:3000/hosts -X POST -d "sn=APCgCoDvvYT8fmVCHhCqdKrC2222222&model=Tunnel&detail=Test" -v
Note: Unnecessary use of -X or --request, POST is already inferred.
*   Trying ::1...
* TCP_NODELAY set
* Connected to localhost (::1) port 3000 (#0)
> POST /hosts HTTP/1.1
> Host: localhost:3000
> User-Agent: curl/7.52.1
> Accept: */*
> Content-Length: 59
> Content-Type: application/x-www-form-urlencoded
>
* upload completely sent off: 59 out of 59 bytes
< HTTP/1.1 200 OK
< Content-Type: application/json; charset=utf-8
< ETag: W/"1ce5b42a5ffe4a40c54bc0874601713e"
< Cache-Control: max-age=0, private, must-revalidate
< X-Request-Id: 9d273e0e-01eb-456e-b82a-4a53260dc257
< X-Runtime: 0.225184
< Transfer-Encoding: chunked
<
* Curl_http_done: called premature == 0
* Connection #0 to host localhost left intact
{"id":5,"sn":"APCgCoDvvYT8fmVCHhCqdKrC2222222","model":"Tunnel","detail":"Test","created_at":"2019-10-09T12:47:05.208Z","updated_at":"2019-10-09T12:47:05.321Z"}root@search:/opt/ssh-bridge#
```

### curl命令选项大全

| commands                    | 作用                                |
|:------------------------|:-------------------------------         |
| -a/--append |  上传文件时，附加到目标文件 |
| -A/--user-agent <string> |  设置用户代理发送给服务器 |
| -anyauth |  可以使用“任何”身份验证方法 |
| -b/--cookie <name=string/[file](http://man.linuxde.net/file "file命令")> |  cookie字符串或文件读取位置 |
|      --basic |  使用HTTP基本验证 |
| -B/--use-ascii |  使用ASCII /文本传输 |
| -c/--cookie-jar <file> |  操作结束后把cookie写入到这个文件中 |
| -C/--continue-[at](http://man.linuxde.net/at "at命令") <offset> |  断点续转 |
| -d/--data <data> |  HTTP POST方式传送数据 |
|      --data-ascii <data> |  以ascii的方式post数据 |
|      --data-binary <data> |  以二进制的方式post数据 |
|      --negotiate |  使用HTTP身份验证 |
|      --digest |  使用数字身份验证 |
|      --disable-eprt |  禁止使用EPRT或LPRT |
|      --disable-epsv |  禁止使用EPSV |
| -D/--[dump](http://man.linuxde.net/dump "dump命令")-header <file> |  把header信息写入到该文件中 |
|      --egd-file <file> |  为随机数据(SSL)设置EGD socket路径 |
|      --tcp-nodelay |  使用TCP_NODELAY选项 |
| -e/--referer |  来源网址 |
| -E/--cert <cert[:[passwd](http://man.linuxde.net/passwd "passwd命令")]> |  客户端证书文件和密码 (SSL) |
|      --cert-[type](http://man.linuxde.net/type "type命令") <type> |  证书文件类型 (DER/PEM/ENG) (SSL) |
|      --key <key> |  私钥文件名 (SSL) |
|      --key-type <type> |  私钥文件类型 (DER/PEM/ENG) (SSL) |
|      --pass <pass> |  私钥密码 (SSL) |
|      --engine <eng> |  加密引擎使用 (SSL). "--engine list" for list |
|      --cacert <file> |  CA证书 (SSL) |
|      --capath <directory> |  CA目录 (made using c_rehash) to verify peer against (SSL) |
|      --ciphers <list> |  SSL密码 |
|      --compressed |  要求返回是压缩的形势 (using deflate or [gzip](http://man.linuxde.net/gzip "gzip命令")) |
|      --connect-timeout <seconds> |  设置最大请求时间 |
|      --create-[dirs](http://man.linuxde.net/dirs "dirs命令") |  建立本地目录的目录层次结构 |
|      --crlf |  上传是把LF转变成CRLF |
| -f/--fail |  连接失败时不显示http错误 |
|      --ftp-create-dirs |  如果远程目录不存在，创建远程目录 |
|      --ftp-method [multicwd/nocwd/singlecwd] |  控制CWD的使用 |
|      --ftp-pasv |  使用 PASV/EPSV 代替端口 |
|      --ftp-skip-pasv-[ip](http://man.linuxde.net/ip "ip命令") |  使用PASV的时候,忽略该IP地址 |
|      --ftp-ssl |  尝试用 SSL/TLS 来进行ftp数据传输 |
|      --ftp-ssl-reqd |  要求用 SSL/TLS 来进行ftp数据传输 |
| -F/--form <name=content> |  模拟http表单提交数据 |
|      --form-string <name=string> |  模拟http表单提交数据 |
| -g/--globoff |  禁用网址序列和范围使用{}和[] |
| -G/--get |  以get的方式来发送数据 |
| -H/--header <line> |  自定义头信息传递给服务器 |
|      --ignore-content-length |  忽略的HTTP头信息的长度 |
| -i/--include |  输出时包括protocol头信息 |
| -I/--[head](http://man.linuxde.net/head "head命令") |  只显示请求头信息 |
| -j/--junk-session-cookies |  读取文件进忽略session cookie |
|      --interface <interface> |  使用指定网络接口/地址 |
|      --krb4 <level> |  使用指定安全级别的krb4 |
| -k/--insecure |  允许不使用证书到SSL站点 |
| -K/--config |  指定的配置文件读取 |
| -l/--list-only |  列出ftp目录下的文件名称 |
|      --limit-rate <rate> |  设置传输速度 |
|      --local-port<NUM> |  强制使用本地端口号 |
| -m/--max-[time](http://man.linuxde.net/time "time命令") <seconds> |  设置最大传输时间 |
|      --max-redirs <num> |  设置最大读取的目录数 |
|      --max-filesize <bytes> |  设置最大下载的文件总量 |
| -M/--manual |  显示全手动 |
| -n/--netrc |  从netrc文件中读取用户名和密码 |
|      --netrc-optional |  使用 .netrc 或者 URL来覆盖-n |
|      --ntlm |  使用 HTTP NTLM 身份验证 |
| -N/--no-buffer |  禁用缓冲输出 |
| -o/--output |  把输出写到该文件中 |
| -O/--remote-name |  把输出写到该文件中，保留远程文件的文件名 |
| -p/--proxytunnel |  使用HTTP代理 |
|      --proxy-anyauth |  选择任一代理身份验证方法 |
|      --proxy-basic |  在代理上使用基本身份验证 |
|      --proxy-digest |  在代理上使用数字身份验证 |
|      --proxy-ntlm |  在代理上使用ntlm身份验证 |
| -P/--ftp-port <address> |  使用端口地址，而不是使用PASV |
| -q |  作为第一个参数，关闭 .curlrc |
| -Q/--quote <cmd> |  文件传输前，发送命令到服务器 |
| -r/--range <range> |  检索来自HTTP/1.1或FTP服务器字节范围 |
| --range-file |  读取（SSL）的随机文件 |
| -R/--remote-time |  在本地生成文件时，保留远程文件时间 |
|      --retry <num> |  传输出现问题时，重试的次数 |
|      --retry-delay <seconds> |  传输出现问题时，设置重试间隔时间 |
|      --retry-max-time <seconds> |  传输出现问题时，设置最大重试时间 |
| -s/--silent |  静默模式。不输出任何东西 |
| -S/--show-error |  显示错误 |
|      --socks4 <[host](http://man.linuxde.net/host "host命令")[:port]> |  用socks4代理给定主机和端口 |
|      --socks5 <host[:port]> |  用socks5代理给定主机和端口 |
|      --stderr <file> |   |
| -t/--[telnet](http://man.linuxde.net/telnet "telnet命令")-option <OPT=val> |  Telnet选项设置 |
|      --trace <file> |  对指定文件进行debug |
|      --trace-ascii <file> |  Like --跟踪但没有hex输出 |
|      --trace-time |  跟踪/详细输出时，添加时间戳 |
| -T/--upload-file <file> |  上传文件 |
|      --url <URL> |  Spet URL to work with |
| -u/--user <user[:password]> |  设置服务器的用户和密码 |
| -U/--proxy-user <user[:password]> |  设置代理用户名和密码 |
| -[w](http://man.linuxde.net/w "w命令")/--[write](http://man.linuxde.net/write "write命令")-out [format] |  什么输出完成后 |
| -x/--proxy <host[:port]> |  在给定的端口上使用HTTP代理 |
| -X/--request <[command](http://man.linuxde.net/command "command命令")> |  指定什么命令 |
| -y/--speed-time |  放弃限速所要的时间，默认为30 |
| -Y/--speed-limit |  停止传输速度的限制，速度时间 |


最后推荐一个Linux命令学习的好网站————>>[请点击我](https://man.linuxde.net)

