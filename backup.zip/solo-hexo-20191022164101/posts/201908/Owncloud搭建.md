title: Owncloud搭建
date: '2019-08-29 12:11:05'
updated: '2019-08-29 12:11:05'
tags: [Linux]
permalink: /articles/2019/08/29/1567051865992.html
---
&nbsp;&nbsp;&nbsp;&nbsp;ownCloud 是一个开源免费专业的私有云存储项目，它能帮你快速在个人电脑或服务器上架设一套专属的私有云文件同步网盘，可以像 Dropbox 那样实现文件跨平台同步、共享、版本控制、团队协作等等。ownCloud 能让你将所有的文件掌握在自己的手中，只要你的设备性能和空间充足，那么用其来几乎没有任何限制。

### **第一步、构建LAMP环境**

1.Linux系统软件的安装最方便的还是在线的模式，Debian分支使用apt-get安装，RedHat分支使用yum安装。安装命令如下：

```
yum install -y httpd php php-mysql mariadb-server mariadb sqlite php-dom php-mbstring php-gd php-pdo wget

```

2.设置SELinux允许owncloud写数据，SELinux 是 Linux中提供的强制访问控制(MAC）系统，当然如果你关闭了就不需要输入这条了，查看自己的linux有没有开启的方法是，sell输入 /usr/sbin/sestatus -v ，如果SELinux status参数为enabled即为开启状态。

```
setsebool -P httpd_unified 1

```

3.防火墙设置

```
firewall-cmd --state //查看防火墙是否开启
firewall-cmd --permanent --zone=public --add-service=http  //设置可信
firewall-cmd --permanent --zone=public --add-service=https  //设置可信
firewall-cmd --reload  //重新载入

```

4.自启和启动服务

```
systemctl enable httpd.service
systemctl enable mariadb.service
systemctl start httpd.service
systemctl start mariadb.service

```

### **第二步安装owncloud**

1.下载owncloud

```
wgethttps://download.owncloud.org/community/owncloud-7.0.0.tar.bz2  
tar -jxvf owncloud-7.0.0.tar.bz2 -C/var/www/html/  
chown -R apache.apache/var/www/html/owncloud/  

```

2.数据库配置

配置MariaDB实例：```mysql_secure_installation```在设置过程这都输入Y并回车。登录到MySQL服务器，使用以下命令:```mysql -u root -p```创建owncloud数据库和用户:  

```
mysql> create database clouddb;
mysql> grant all on clouddb.* to 'clouddbuser'@'localhost' identified by 'password';
mysql> flush privileges;
mysql> quit;

```

3.Apache服务器配置

```
vim /etc/httpd/conf.d/owncloud.conf 在配置文件中添加以下代码
<IfModule mod_alias.c>
Alias /owncloud /var/www/html/owncloud
</IfModule>
<Directory “/var/www/html/owncloud”>
Options Indexes FollowSymLinks
AllowOverride All
Order allow,deny
allow from all
</Directory>

```

重启启动Apache和MariaDB服务
systemctl restart httpd.service
systemctl restart mariadb.service

4.owncloud配置
打开浏览器即可访问http://IP，他将显示初始owncloud设置页。
![页面图](https://www.logcg.com/wp-content/uploads/2016/09/%E5%9B%BE%E7%89%87-1-2.png)

#### **补充**
owncloud默认上传文件存储在网站根目录的data文件夹下。owncloud已经对文件访问权限进行了一系列的限制，确保无法直接通过文件固定地址进行下载。如果你不想让这些文件存储到网站根目录下的data文件夹，你也可以修改上传文件到服务器上的其他目录。

如果你是新建站点，可以在owncloud配置时直接配置owncloud上传文件所属目录。如果你的owncloud站点已经建立，可以通过以下方式进行修改：
1、停止web服务

2、查看config/config.php文件中已有的datadirectory（例如为：/var/www/owncloud/data）

3、修改config/config.php文件中的datadirectory（例如修改为：/media/usbdisk/ocdata/）

```
    'datadirectory' => '/var/www/owncloud/data',

    修改为：

    'datadirectory' => '/media/usbdisk/ocdata/',

```
4、将/var/www/owncloud/data目录下的所有文件移动到新的/media/usbdisk/ocdata/目录下。

```
cp -ar /var/www/owncloud/data/. /media/usbdisk/ocdata/

```
5、修改/media/usbdisk/ocdata/目录所述的组及用户与原/var/www/owncloud/data目录相同，例如所述组和用户都修改为apache。

```
chown -R apache:apache /media/usbdisk/ocdata

```

6、启动web服务。

以上修改后，你的owncloud后续上传的文件将会存放到新的目录下。在第4步操作的过程中一定要将所有文件都拷贝到新的目录下，如不完全拷贝，可能会出现在web页面无法看到以前上传文件的问题