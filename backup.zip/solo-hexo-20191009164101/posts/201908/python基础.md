title: python基础
date: '2019-08-29 12:11:07'
updated: '2019-08-29 12:11:07'
tags: [python]
permalink: /articles/2019/08/29/1567051867899.html
---
### 分类

* 数值型

    整数(int)、浮点数(float)、复数(complex)、布尔值(bool)

* 序列对象

    序列是Python中最基本的数据结构。序列中的每个元素都分配一个数字 - 它的位置，或索引，第一个索引是0，第二个索引是1，依此类推。
Python有6个序列的内置类型，但最常见的是字符串str、列表list、元祖tuple。
序列都可以进行的操作包括索引，切片，加，乘，检查成员
    

* 键值对

    集合set、字典dict

线性结构：
    列表、元祖、字符串、（序列对象都是线性结构）
    bytes及bytearray
    线性结构的查询时间复杂度是On，即随着数据规模的增大而增加耗时
    set、dict等结构，内部使用hash值作为key,时间复杂度可以做到O1，查询时间和数据规模无关。
    
标识符命名
-----------------

变量是标识符的例子。 *标识符* 是用来标识 *某事物* 的名名称。在命名标识符的时候必须遵循一些规则：

-   标识符的第一个字符必须是字母（大写 ASCII 或小写 ASCII 或 Unicode 字符）或者下划线 （`_`）。
-   标识符的其余部分可以由字母、下划线 (`_`) 或者数字 (0-9) 组成。
-   标识符的名称区分大小写。例如， `myname` 和 `myName` 是 *不* 相同的。注意前者中的小写 `n` 和后者中的大写 `N` 。
-   *有效* 标识符名称的例子有 `i`、`name_2_3`。 *无效* 标识符名称的例子有 `2things`、`this is spaced out`、`my-name` 以及 `>a1b2_c3`。

**数据类型判断**

```
type()

type(obj) 返回类型

isintance()

isintance(obj,class_or_tuple) 返回布尔值

issubclass(cls,class_or_tuple) 判断类型cls是否是某种类型的子类或
                                元组中列出来的某个类型的子类

issubclass(bool,(str,int))

```

**类型转换**

```
map(type,iterable) 返回的是一个迭代器，需要使用list或tuple调用

int(x) 转换为整数类型

float(X) 转换为一个浮点数

complex(x) 返回一个复数

bool(x) 返回布尔值，False或True

bytes()

bytearray()

set()

dict()

list()

ceiling() 向上取整，得到最接近原数但是大于原数的部分

floor() 向下取整，得到最接近原数但是小于原数的部分

Round() 四舍五入的四舍六入五取偶

//  整除且向下取整

```

**模块math\\random函数\\datetime**

```
###math模块

import math
数字的处理函数：
math.ceil()  向上取整
math.floor() 向下取整
divmod(x,y) 等价于tuple(x//y,x%y)
abs(x) 绝对值
min()
max()
pow(x,y)等于x**y
math.sqrt() 返回数字的平方根

进制函数,返回值是字符串
bin()   二进制
oct()   十进制
hex()   十六进制
math.pi   3.14....
math.e   自如常数

### 模块random

import random
random.randint(1,6) #随机取出一个数范围是[1,6]
random.randrange(1,6) #随机取出一个数范围是[1,6)
random.choice([1,3,5,7]) 随机取数
random.shuffle(lst0) 打乱就地修改,该函数没有返回值返回的是none
random.sample(['a','b','c'],2)  打乱就地修改，且返回2个列表中的两个参数



### 模块datetime

timedelta
日期格式化
    类方法strptime（date_string,format),返回datetime对象
    对象方法strftime(format),返回字符串
import datetime
dt = datetime.datetime.strptime("21/11/06 16:30","%d/%m/%y %H:%M")
print(dt.strftime("%Y-%m-%d %H:%M:%S"))
print("{0:%Y}/{0:%m}/{0:%d}{0:%H}::{0:%M}::{0:%S}".format(dt))

```



#### 字符串 '' "" """

字符串是单引号、双引号、三引号引住的字符序列，不可变对象（Python3起，字符串的编码都是Unicode类型）

原始字符串：如果你需要指定一些没有特殊处理（转义序列等）的字符串，那么你需要指定一个 原始 字符串，指定方法是在字符串前面加上 r 或者 R。`r"Newlines are indicated by \n"
`

* 字符串分割
    
    **str.split**

    `str.split(sep=None,maxsplit=-1)  -> liist of strings 返回字符串列表`

    `str.rsplit(sep=None,maxsplit=-a) 从右到左`
    
    sep指定分割符，maxsplit指定分割的次数，-1表示遍历整个字符串
    
    **str.partition**
    
    `str.partition(sep) ->(head, sep, tail)`
    
    遇到分隔符就把字符串分割成两部分，返回头、分隔符、尾三部分的三元组
    

```
    例子：
    In $: '1,2,3'.split(',')
    Out$: ['1', '2', '3']

    In $: '1 2 3'.split(maxsplit=1)
    Out$: ['1', '2 3']

    In $: '   1   2   3   '.split()
    Out$: ['1', '2', '3']

    In $: '1,2,3'.partition(',')
    Out$: ('1', ',', '2,3')
```


#### 字符串常用函数

```
    str.replace(old,new[,count]) 字符串中找到匹配替换为新子串，返回新字符串.
    str.strip([chars]) 如果chars没有指定，去除两端的空白字符
       .lstrip   从左开始
       .rstrip   从右开始
    str.find(sub[,start[,end]]) 从左至右，查找子串sub。找到返回索引，没找到返回-1
       .rfind(sub[,start[,end]])  从右至左，查找子串sub。找到返回索引，没找到返回-1
    str.index(sub[,start[,end]])
    str.rindex(sub[,start[,end]])
    str.(suffix[,start[,end]]) -> bool    指定区间中，字符串是否是suffix结尾
    str.(prefix[,start[,end]]) -> bool  指定区间中，字符串是否是prefix开头
    str.upper() 全大写
    str.lower() 全小写
    str.pace()是否只包含空白字符
    str.swapcase() 交互大小写
    str.title() 返回字符串的标题版本，其中单词以大写字符开头，其余字符为小写。
    str.capitalize() 返回字符串的副本，其首字符大写，其余字符小写。
    str.center(width[,fillchar]) width 打印宽带，fillchar填充的字符
    str.zfill(width) 居右
    str.ljust(width[,fillchar]) 左对齐字符串宽度
    str.rjust(width[,fillchar]) 右对齐字符串宽度
    
    
``` 


* 字符串判断is系统

```
    str.isalnum() -> bool 是否是字母和数字组成
    str.isalpha() 是否是字母
    str.isdecimal()是否只包含十进制数字
    str.is digit()是否全部数字
    str.identifier()是不是字母和下划线开头，其他都是字母，数字，下划线
    
    
```



* format函数格式字符串语法

    `"{} {xxx} {}".format(*args,**kwargs,***kwargs) -> str`

```
    列子

    In $:"The sum of 1 + 2 is {0}".format(1+2)
    Out$:'The sum of 1 + 2 is 3

```


#### 列表list [] 列表是不可变的

    list、链表、queue、stack

* 列表解析式

    语法
    `[返回值 for 元素 in 可迭代对象 if条件]`
生成器表达式

* 列表函数

```
    list.index() 返回索引号
    list.count(x) 返回列表中x的出现次数
    len(list) 返回列表的长度
    list.append(object) 将object的新项追加到列表中的末尾（返回值None就地修改 ）
    list.insert(index,object) 插入object项到index（返回值None就地修改）
    list.extend(iteratable)  将可迭代对象的元素追加进来，返回None 就地修改
    list.remove(value) None  从左至右查找第一个匹配value的值后移除,On
    list.pop([index]) 就地修改弹出index的元素
    list.clear()  清除列表中所有元素
    list.reversed() -> None 将列表中元素反转,就地修改
    sort(key=None,reverse=False) -> None 对列表元素进行排序，就地修改，默认升序

    ####枚举
    enumerate(seq,start=0) 迭代一个序列，返回索引数字和元素构成的二元组，
                                start表示索引开始的数字m,默认为0
    
    a = list(range(10,20))
    for i in enumerate(a):
             print(i)

    ####迭代器
    iter(iterable) 将一个可迭代对象封装成为一个迭代器
    
    ####取元素
    next(iterator[,default]) 对一个迭代器取下一个元素，如果全部元素都取过了，再次next会抛出stopiteration异常

    _、__、___下划线代码前一次输出、倒数第二次、倒数第三次的out输出结果，

    _oh  输出历史

    _dh  目录历史
    
```


* 列表复制
    
    shadow copy 影子拷贝，遇到引用类型，只是复制了一个引用而已
        
        lst2 = lst.copy()
    深拷贝 copy模块提供了deepcopy
        
        import copy
        lst1 = copy.deepcopy(lst0)

        lst = [1,2,3,4]
        lst1 = lst #同一个对象
        lst2 = lst.copy() #内容相同，不同的对象，遇到引用类型不会复制对象，只会复制地址。
        lst3 = copy.deepcopy(lst) #内容相同，不同的对象，如果有引用类型也会复制出不同的对象


#### 元组tuple() ()元组不可变

* namedtuple 命名元祖
    
        返回一个元祖的子类，并定义了字段

```
    import collections
    Point = collections.namedtuple('P',['x','y'])
    form collections import namedtuple
    Point = namedtuple('stu','name age')
    tom = stu('tom',20)
    jerry = stu('jerry',18)

```


#### 集合set  可变的、无序的、不重复的元素的集合

    使用大括号{}或者set{} 函数创建集合，注意创建一个空集合必须用set()而不是{},因为{}是用来创建一个空字典。
    
    创建格式：
    
```
parame = {value01,value02,....}
或者
set{value}

```

    set的元素不可索引，且要求必须可以hash。
    
    不可hash的类型有list、set。
    
    可hash的类型：数值型（int、flocat、complex）、布尔型（true、false）、
    字符串、bytes、tuple、None等都是不可变类型可hash。
    
    
集合内置方法：

| 方法                    | 描述                                                                                |
|:-----------------------------------|:-------------------------------------------------------------------------|
| add()                              | 为集合添加元素                                                           |
| clear()                            | 移除集合中的所有元素                                                     |
| copy()                             | 拷贝一个集合                                                             |
| difference()或-                    | 返回多个集合的差集                                                       |
| difference_update()或-=            | 获取和多个集合的差集并就地修改。                                         |
| discard()                          | 删除集合中指定的元素                                                     |
| intersection()或&                  | 返回集合的交集                                                           |
| intersection_update()或&=          | 获取和多个集合的交集，并就地修改                                         |
| isdisjoint()                       | 判断两个集合是否包含相同的元素，如果没有返回true，否则返回false          |
| issubset()                         | 判断指定集合是否为该方法参数集合的子集                                   |
| issuperset()                       | 判断该方法的参数集合是否为指定集合的子集                                 |
| pop()                              | 随机移除元素，空集返回keyError                                           |
| remove()                           | 移除指定元素                                                             |
| symmetric_difference()             | 返回两个集合中不重复的元素集合                                           |
| symmetric_difference_update()      | 移除当前集合中在另外一个指定集合相同的元素，并将另外一个指定集合中不同的元素插入到当前集合中。   |
| union()或\|                        | 返回和多个集合合并后的新的集合即并集                                     |
| update()或\|=                      | 和多个集合合并，就地修改                                                 |


#### bytes、bytearray
    
*字符串与bytes
    
    字符串是字符组成的有序序列，字符可以使用编码来理解
    
    bytes是字节组成的有序的不可变序列
    
    bytearray是字节组成的有序的可变序列

* 编码与解码

    字符串按照不同的字符集编码encode返回字节序列bytes
        
        string.encode(encoding='utf-8',errors='strict') -> bytes

    字节序列按照不同的字符集解码decode返回字符串
        
        bytes.decode(encoding='utf-8',errors='strict') -> str
        
        bytearray.decode(encoding='utf-8',errors='strict') -> str



#### 字典dict 

    字典是key-value键值对的数据的集合，不可变、
    无序的、key不可重复。
    
    d = {key1 : value1, key2 : value2 }

* 字典内置方法


| 方法                    | 描述                                                                                |
|:-----------------------------------|:-------------------------------------------------------------------------|
| dict.clear()                              | 删除字典内所有元素                                                          |
| dict.fromkeys(seq,val)                            |    创建一个新字典，以序列seq中元素做字典的键，val为字典所有键对应的初始值                                                 |
| dict.get(key,default=None)                             | 返回指定键的值，如果值不在字典中返回default值                                                             |
| key in dict                    | 如果键在字典dict里返回true，否则返回false                                                       |
| dict.items()           | 以列表返回可遍历的键，值。                                         |
| dict.keys()                          | 返回一个迭代器，可以使用list()来转换为列表           |
| dict.update()           | 更新元素到dict。                                         |
| dict.values()                          | 返回一个迭代器，可以使用list()来转换为列表           |
| dict.pop(key,[,default])           | 删除字典给定键 key 所对应的值，返回值为被删除的值。key值必须给出。 否则，返回default值。                                         |
| dict.popitem()                          | 随机返回并删除字典中的一对键值对          |


#### Python函数

* 语法
    def 函数名 (参数列表):
        函数体
        [return 返回值]

    Python函数没有return语句，隐式返回一个none值